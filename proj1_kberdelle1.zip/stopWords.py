#!/usr/bin/env python

"""
A filter that removes the following words from the file: the, be, to, of, and, a, in, that, have, I.
"""

import fileinput


def process(line):
    """For each line of input, remove the stop words."""
    lineList = line.split()
    for word in lineList:
        if word.lower() not in ('the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'i'):
            print(word)

for line in fileinput.input():
    process(line)
