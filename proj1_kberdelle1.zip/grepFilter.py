#!/usr/bin/env python

"""
A filter that splits lines of text into one word per line.
"""

import fileinput


def process(line):
    """For each line of input, put each word on a new line."""
    lineList = line.split()
    for word in lineList:
        print(word)


for line in fileinput.input():
    process(line)
